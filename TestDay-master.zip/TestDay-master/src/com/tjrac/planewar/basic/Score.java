package com.tjrac.planewar.basic;

public interface Score {
  public int getScore();//获得分数
}
