 package com.tjrac.lhw.test;

public class MyTest {
//这是林宏伟创建的、。。。初始东东
	public static void main(String[] args) {
		System.out.println("哈哈哈我修改了");
//		xxxxxxxxxx
	}
}
