package com.tjrac.planewar.father;
/*
敌人类 Enemy 继承Flying 飞行类
所有敌机类 的父类
*/
public class Enemy extends FlyObject{

	@Override
	public void movetheobject() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean moveOut() {
		// TODO Auto-generated method stub
		return false;
	}

}
